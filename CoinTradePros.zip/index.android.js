/**
 * CoinTradePros.com React Native App
 * http://www.cointradepros.com/
 * @flow
 */

import React, { Component } from 'react';
import { AppRegistry } from 'react-native';

import App from './App/container';
AppRegistry.registerComponent('CoinTradePros', () => App);